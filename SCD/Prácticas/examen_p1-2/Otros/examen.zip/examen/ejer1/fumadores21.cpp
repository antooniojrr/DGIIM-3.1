/**
 * @file fumadores21.cpp
 * @brief Resolución ejercicio 1 examen
 * @author Carlos Bermúdez Padrón DGIIM
 * @date 15 de noviembre de 2023
 */
#include <iostream>
#include <cassert>
#include <thread>
#include <mutex>
#include <random> 
#include <chrono> 
#include "scd.h"

using namespace std ;
using namespace scd ;

const int num_fumadores = 3 ;

//Semáforos

Semaphore mostr_vacio[num_fumadores] = {1,1,1};
Semaphore ingr_disp[num_fumadores] = {0,0,0};

//-------------------------------------------------------------------------
// Función que simula la acción de producir un ingrediente, como un retardo
// aleatorio de la hebra (devuelve número de ingrediente producido)

int producir_ingrediente()
{
   
   chrono::milliseconds duracion_produ( aleatorio<10,100>() );

   // informa de que comienza a producir
   cout << "Estanquero : empieza a producir un ingrediente (" << duracion_produ.count() << " milisegundos)" << endl;

   // espera bloqueada un tiempo igual a ''duracion_produ' milisegundos
   this_thread::sleep_for( duracion_produ );

   const int num_ingrediente = aleatorio<0,num_fumadores-1>() ;

   // informa de que ha terminado de producir
   cout << "Estanquero : termina de producir ingrediente " << num_ingrediente << endl;

   return num_ingrediente ;
}

//----------------------------------------------------------------------
// función que ejecuta la hebra del estanquero

void funcion_hebra_estanquero(){
   int 
      ingrediente1,
      ingrediente2;
   while(true){
      //Producimos el primer ingrediente
      ingrediente1 = producir_ingrediente(); 
      //Producimos ingredientes hasta obtener uno distinto al primero                                                                         
      do{
         ingrediente2 = producir_ingrediente();
      }while(ingrediente1 == ingrediente2);                                                                           
      //Informamos de que se ha conseguido producir los dos ingredientes distintos
      cout <<"Estanquero ha producido los ingredientes " << ingrediente1 << " y " << ingrediente2 << endl;
      //Esperamos a que los dos huecos del mostrador queden vacíos 
      mostr_vacio[ingrediente1].sem_wait();
      mostr_vacio[ingrediente2].sem_wait();
      //Una vez vacío informamos de que los ingredientes han sido colocados en el mostrador
      cout << "Estanquero : ingredientes " << ingrediente1 << " y " << ingrediente2 << " en el mostrador" << endl;
      //Damos la señal de que han sido colocados los ingredientes, ya pueden recogerlos
      ingr_disp[ingrediente1].sem_signal();
      ingr_disp[ingrediente2].sem_signal();
    }

}

//-------------------------------------------------------------------------
// Función que simula la acción de fumar, como un retardo aleatoria de la hebra

void fumar( int num_fumador )
{

   // calcular milisegundos aleatorios de duración de la acción de fumar)
   chrono::milliseconds duracion_fumar( aleatorio<20,200>() );

   // informa de que comienza a fumar

    cout << "\tFumador " << num_fumador << "  :"
          << " empieza a fumar (" << duracion_fumar.count() << " milisegundos)" << endl;

   // espera bloqueada un tiempo igual a ''duracion_fumar' milisegundos
   this_thread::sleep_for( duracion_fumar );

   // informa de que ha terminado de fumar

    cout << "\tFumador " << num_fumador << "  : termina de fumar, comienza espera de ingrediente." << endl;

}

//----------------------------------------------------------------------
// función que ejecuta la hebra del fumador
void  funcion_hebra_fumador( int num_fumador )
{
   while( true ){

        ingr_disp[num_fumador].sem_wait();
        cout << "\tFumador " << num_fumador << "  ha retirado su ingrediente" << endl;
        mostr_vacio[num_fumador].sem_signal();
        fumar(num_fumador);
   }
}

//----------------------------------------------------------------------

int main(){
   cout << "*************************** Ejercicio 1 ***************************" << endl << flush ;

    thread estanco(funcion_hebra_estanquero);
    thread hebra_fumadora[num_fumadores];
    for(unsigned i=0;i<num_fumadores;i++){
      hebra_fumadora[i]=thread(funcion_hebra_fumador, i);      
   }
    estanco.join();
   for(unsigned i=0;i<num_fumadores;i++){
      hebra_fumadora[i].join();
   }
}
