/**
 * @file fumadores.cpp
 * @brief Resolución de problema fumadores
 * @author Carlos Bermúdez Padrón DGIIM
 * @date 13 de noviembre de 2023
 */
#include <iostream>
#include <cassert>
#include <thread>
#include <mutex>
#include <random> // dispositivos, generadores y distribuciones aleatorias
#include <chrono> // duraciones (duration), unidades de tiempo
#include "scd.h"

using namespace std ;
using namespace scd ;

// numero de fumadores 

const int num_fumadores = 3 ;

//Semáforos

Semaphore mostr_vacio=1;
Semaphore ingr_disp[num_fumadores] = {0,0,0};

//-------------------------------------------------------------------------
// Función que simula la acción de producir un ingrediente, como un retardo
// aleatorio de la hebra (devuelve número de ingrediente producido)

int producir_ingrediente()
{
   // calcular milisegundos aleatorios de duración de la acción de fumar)
   chrono::milliseconds duracion_produ( aleatorio<10,100>() );

   // informa de que comienza a producir
   cout << "Estanquero : empieza a producir ingrediente (" << duracion_produ.count() << " milisegundos)" << endl;

   // espera bloqueada un tiempo igual a ''duracion_produ' milisegundos
   this_thread::sleep_for( duracion_produ );

   const int num_ingrediente = aleatorio<0,num_fumadores-1>() ;

   // informa de que ha terminado de producir
   cout << "Estanquero : termina de producir ingrediente " << num_ingrediente << endl;

   return num_ingrediente ;
}

//----------------------------------------------------------------------
// función que ejecuta la hebra del estanquero

void funcion_hebra_estanquero( )
{
    int ingrediente;
    while(true){
   // for (int j=0; j<5; j++){
        ingrediente = producir_ingrediente();
        mostr_vacio.sem_wait();
        cout << "Estanquero : ingrediente " << ingrediente << " en el mostrador" << endl;
        ingr_disp[ingrediente].sem_signal();
    }

}

//-------------------------------------------------------------------------
// Función que simula la acción de fumar, como un retardo aleatoria de la hebra

void fumar( int num_fumador )
{

   // calcular milisegundos aleatorios de duración de la acción de fumar)
   chrono::milliseconds duracion_fumar( aleatorio<20,200>() );

   // informa de que comienza a fumar

    cout << "\tFumador " << num_fumador << "  :"
          << " empieza a fumar (" << duracion_fumar.count() << " milisegundos)" << endl;

   // espera bloqueada un tiempo igual a ''duracion_fumar' milisegundos
   this_thread::sleep_for( duracion_fumar );

   // informa de que ha terminado de fumar

    cout << "\tFumador " << num_fumador << "  : termina de fumar, comienza espera de ingrediente." << endl;

}

//----------------------------------------------------------------------
// función que ejecuta la hebra del fumador
void  funcion_hebra_fumador( int num_fumador )
{
   while( true ){

        ingr_disp[num_fumador].sem_wait();
        cout << "\tFumador " << num_fumador << "  ha retirado su ingrediente" << endl;
        mostr_vacio.sem_signal();
        fumar(num_fumador);
   }
}

//----------------------------------------------------------------------

int main(){
   cout << "******************************************************************" << endl
        << "************************* Fumadores ******************************" << endl
        << "******************************************************************" << endl
        << flush ;

    thread estanco(funcion_hebra_estanquero);
    thread hebra_fumadora[num_fumadores];
    for(unsigned i=0;i<num_fumadores;i++){
      hebra_fumadora[i]=thread(funcion_hebra_fumador, i);      
   }
    estanco.join();
   for(unsigned i=0;i<num_fumadores;i++){
      hebra_fumadora[i].join();
   }
}
