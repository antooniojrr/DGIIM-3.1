/**
 * @author Carber
*/


#include <iostream>
#include <iomanip>
#include <cassert>
#include <random>
#include <thread>
#include "scd.h"

using namespace std ;
using namespace scd ;

constexpr int
   VACIO     = -1,
   num_fumadores = 3;
   
constexpr int               
   min_ms    = 5,     // tiempo minimo de espera en sleep_for
   max_ms    = 20 ;   // tiempo máximo de espera en sleep_for


mutex
   mtx ;                 // mutex de escritura en pantalla

    



int producir_ingrediente(){
   // calcular milisegundos aleatorios de duración de la acción de fumar)
   chrono::milliseconds duracion_produ( aleatorio<10,100>() );

   // informa de que comienza a producir
   cout << "Estanquero : empieza a producir ingrediente (" << duracion_produ.count() << " milisegundos)" << endl;

   // espera bloqueada un tiempo igual a ''duracion_produ' milisegundos
   this_thread::sleep_for( duracion_produ );

   const int num_ingrediente = aleatorio<0,num_fumadores-1>() ;

   // informa de que ha terminado de producir
   cout << "Estanquero : termina de producir ingrediente " << num_ingrediente << endl;

   return num_ingrediente ;
}

// *****************************************************************************
// clase para monitor buffer, version FIFO, semántica SC, multiples prod/cons

class Estanco : public HoareMonitor{
 private:

 int mostrador;
 CondVar                    
   mostrador_libre,
   ingrediente_disponible[num_fumadores];

 public:                    // constructor y métodos públicos
   Estanco() ;             // constructor
   void  obtenerIngrediente(int i);                
   void Fumar( int i );
   void ponerIngrediente(int ingrediente);
   void esperarRecogidaIngrediente();
} ;
// -----------------------------------------------------------------------------

Estanco::Estanco(){
   mostrador            = VACIO;
   mostrador_libre      = newCondVar();
   for (int i = 0; i < num_fumadores; i++) ingrediente_disponible[i] = newCondVar();
   
}
// -----------------------------------------------------------------------------


void Estanco::obtenerIngrediente(  int i ){
   if(mostrador!=i)
      ingrediente_disponible[i].wait();
   mostrador=VACIO;


   mtx.lock();
   cout << "\tFumador " << i << "  ha retirado su ingrediente" << endl;
   mtx.unlock();
   
   mostrador_libre.signal();
}
// -----------------------------------------------------------------------------

void Estanco::Fumar(int i){
   
   // calcular milisegundos aleatorios de duración de la acción de fumar)
   chrono::milliseconds duracion_fumar( aleatorio<20,200>() );

   // informa de que comienza a fumar

    cout << "\tFumador " << i << "  :"
          << " empieza a fumar (" << duracion_fumar.count() << " milisegundos)" << endl;

   // espera bloqueada un tiempo igual a ''duracion_fumar' milisegundos
   this_thread::sleep_for( duracion_fumar );

   // informa de que ha terminado de fumar

    cout << "\tFumador " << i << "  : termina de fumar, comienza espera de ingrediente." << endl;
}


void Estanco::ponerIngrediente(int ingrediente){
   mostrador=ingrediente;
   mtx.lock();
   cout << "Estanquero : ingrediente " << ingrediente << " en el mostrador" << endl;
   mtx.unlock();
   ingrediente_disponible[ingrediente].signal();
}

void Estanco::esperarRecogidaIngrediente(){
   if(mostrador!=VACIO)
      mostrador_libre.wait();
}
// *****************************************************************************
// funciones de hebras

void funcion_hebra_fumador( MRef<Estanco> monitor, int i )
{
   while(true){
    monitor->obtenerIngrediente(i);
    monitor->Fumar(i);
   }
}
// -----------------------------------------------------------------------------

void funcion_hebra_estanquero( MRef<Estanco>  monitor )
{
   while(true){
    int ingrediente = producir_ingrediente();
    monitor->ponerIngrediente(ingrediente);
    monitor->esperarRecogidaIngrediente();
   }
}
// -----------------------------------------------------------------------------

int main(){

   MRef<Estanco> monitor = Create<Estanco>();

   thread hebra_estanquero;
   thread hebra_fumadores[num_fumadores];
   hebra_estanquero = thread(funcion_hebra_estanquero,monitor);   
   for ( int i = 0; i < num_fumadores; i++ )
      hebra_fumadores[i] = thread(funcion_hebra_fumador, monitor, i);
    
   hebra_estanquero.join();
   for ( int i = 0; i < num_fumadores; i++ ) hebra_fumadores[i].join();
}
