/**
 * @file fumadores22.cpp
 * @brief Resolución del ejercicio 2  del examen
 * @author Carlos Bermúdez Padrón  DGIIM
 * @date 15 de noviembre de 2023
 */

#include <iostream>
#include <iomanip>
#include <cassert>
#include <random>
#include <thread>
#include "scd.h"

using namespace std ;
using namespace scd ;

constexpr int
   VACIO            = -1,
   num_fumadores    = 3,
   PRIMER_HUECO     = 0,
   SEGUNDO_HUECO    = 1,
   NUM_INGREDIENTES = 2;

int producir_ingrediente(){
   
   //Calculamos el tiempo de producción
   chrono::milliseconds duracion_produ( aleatorio<10,100>() );       

   cout << "Estanquero : empieza a producir ingrediente (" << duracion_produ.count() << " milisegundos)" << endl;
   // Simulamos el tiempo de producción
   this_thread::sleep_for( duracion_produ );                                
   const int num_ingrediente = aleatorio<0,num_fumadores-1>() ;
   cout << "Estanquero : termina de producir ingrediente " << num_ingrediente << endl;
   return num_ingrediente ;
}


class Estanco : public HoareMonitor{
private:
    int mostrador[NUM_INGREDIENTES];
    CondVar                    
        mostrador_libre[NUM_INGREDIENTES],
        ingrediente_disponible[num_fumadores];

public:                    
    Estanco() ;             
    void  obtenerIngrediente(int i);                
    void Fumar( int i );
    void ponerIngrediente(int ingrediente1, int ingrediente2);
    void esperarRecogidaIngrediente();
} ;
// -----------------------------------------------------------------------------

Estanco::Estanco(){
    for (int i=0; i< NUM_INGREDIENTES; i++) mostrador[i] = VACIO;
    for (int i=0; i< NUM_INGREDIENTES; i++) mostrador_libre[i] = newCondVar();
    for (int i = 0; i < num_fumadores; i++) ingrediente_disponible[i] = newCondVar();
}
// -----------------------------------------------------------------------------


void Estanco::obtenerIngrediente(  int i ){
    //Si en ninguno de los huecos está el ingrediente que necesita
    if(mostrador[PRIMER_HUECO]!=i || mostrador[SEGUNDO_HUECO]!=i)
        ingrediente_disponible[i].wait();
    
    int hueco;

    if(mostrador[PRIMER_HUECO] == i){
        mostrador[PRIMER_HUECO] = VACIO;
        hueco = PRIMER_HUECO;
    }else{
        mostrador[SEGUNDO_HUECO] = VACIO;
        hueco = SEGUNDO_HUECO;
    }

    cout << "\tFumador " << i << "  ha retirado su ingrediente" << endl;
    mostrador_libre[hueco].signal();
}
// -----------------------------------------------------------------------------

void Estanco::Fumar(int i){

    chrono::milliseconds duracion_fumar( aleatorio<20,200>() );                      //Calculamos el tiempo de la acción de fumar
    cout << "\tFumador " << i << "  :" << " empieza a fumar (" << duracion_fumar.count() << " milisegundos)" << endl;
   this_thread::sleep_for( duracion_fumar );                                                // Simulamos el tiempo de la acción de fumar
    cout << "\tFumador " << i << "  : termina de fumar, comienza espera de ingrediente." << endl;
}

// -----------------------------------------------------------------------------

void Estanco::ponerIngrediente(int ingrediente1, int ingrediente2){
   mostrador[PRIMER_HUECO]=ingrediente1;
   mostrador[SEGUNDO_HUECO] = ingrediente2;

   cout << "Estanquero : ingredientes " << ingrediente1 << " y "<<  ingrediente2 << " en el mostrador" << endl;
   
   ingrediente_disponible[ingrediente1].signal();
   ingrediente_disponible[ingrediente2].signal();
}

void Estanco::esperarRecogidaIngrediente(){
   if(mostrador[PRIMER_HUECO] != VACIO || mostrador[SEGUNDO_HUECO]!=VACIO){
      mostrador_libre[PRIMER_HUECO].wait();
      mostrador_libre[SEGUNDO_HUECO].wait();
   }
}
// *****************************************************************************
// funciones de hebras

void funcion_hebra_fumador( MRef<Estanco> monitor, int i )
{
   while(true){
    monitor->obtenerIngrediente(i);
    monitor->Fumar(i);
   }
}
// -----------------------------------------------------------------------------

void funcion_hebra_estanquero( MRef<Estanco>  monitor )
{
   while(true){
    int ingrediente2;
    int ingrediente1 = producir_ingrediente();
    do{
        ingrediente2 = producir_ingrediente();
    }while(ingrediente1 == ingrediente2);
    monitor->ponerIngrediente(ingrediente1, ingrediente2);
    monitor->esperarRecogidaIngrediente();
   }
}
// -----------------------------------------------------------------------------

int main(){
    cout << "*************************** Ejercicio 2 ***************************" << endl << flush ;

   MRef<Estanco> monitor = Create<Estanco>();

   thread hebra_estanquero;
   thread hebra_fumadores[num_fumadores];

   hebra_estanquero = thread(funcion_hebra_estanquero,monitor);   
   for ( int i = 0; i < num_fumadores; i++ )
      hebra_fumadores[i] = thread(funcion_hebra_fumador, monitor, i);
    
   hebra_estanquero.join();
   for ( int i = 0; i < num_fumadores; i++ ) hebra_fumadores[i].join();
}
